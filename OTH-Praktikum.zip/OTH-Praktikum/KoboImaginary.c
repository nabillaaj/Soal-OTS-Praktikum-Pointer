#include <stdio.h>

void koboImaginaryChess(int i, int j, int size, int *Board){
    int moves[8][2] = {{-2, -1}, {-1, -2}, {1, -2}, {2, -1}, {2, 1}, {1, 2}, {-1, 2}, {-2, 1}};
    
    for(int k = 0; k < 8; k++){
        int new_i = i + moves[k][0];
        int new_j = j + moves[k][1];
        
        if(new_i >= 0 && new_i < size && new_j >= 0 && new_j < size){
            *(Board + new_i*size + new_j) = 1;
        }
    }
}

int main(){
    int i, j;
    int Board[8][8] = {0};

    scanf("%d %d", &i, &j);

    koboImaginaryChess(i, j, 8, (int *)Board);

    for(int x = 0; x < 8; x++){
        for(int y = 0; y < 8; y++){
            printf("%d ", Board[x][y]);
        }
        printf("\n");
    }

    return 0;
}