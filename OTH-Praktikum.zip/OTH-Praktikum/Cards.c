#include <stdio.h>

int main() {
    int n, i, j, min_idx, temp, count = 0;
    scanf("%d", &n);
    int cards[n];

    for (i = 0; i < n; i++) {
        scanf("%d", &cards[i]);
    }

    for (i = 0; i < n-1; i++) {
        min_idx = i;
        for (j = i+1; j < n; j++) {
            if (cards[j] < cards[min_idx]) {
                min_idx = j;
            }
        }
        if (min_idx != i) {
            temp = cards[i];
            cards[i] = cards[min_idx];
            cards[min_idx] = temp;
            count++;
        }
    }

    printf("%d", count);
    return 0;
}
